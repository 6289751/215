export type { PasswordProps } from './Password';
export { default } from './Password';
