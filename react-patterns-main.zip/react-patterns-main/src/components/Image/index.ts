export { default } from './Image';
export type { ImageProps } from './Image';
