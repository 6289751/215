export { default } from './AspectRatio';
