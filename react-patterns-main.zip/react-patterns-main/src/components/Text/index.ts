export { default } from './Text';
export type { TextProps } from './Text';
