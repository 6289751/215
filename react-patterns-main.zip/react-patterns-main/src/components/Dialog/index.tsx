export { default, DialogBody, DialogClose, DialogHeader, DialogFooter } from './Dialog';
