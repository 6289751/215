export { default } from './Textarea';
export type { TextareaProps } from './Textarea';
